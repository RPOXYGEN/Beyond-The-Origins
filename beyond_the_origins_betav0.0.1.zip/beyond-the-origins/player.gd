extends CharacterBody2D
const hız = 200
const kosma_carpani = 1.7
const dash_hizi = 700
const dash_bekleme_suresi = 0.6

var son_yon = Vector2.DOWN
var dash_kalan = 0.0
var dash_bekleme = 0.0
var anim_kare = 0
var anim_zamani = 0.0

func _physics_process(delta):
	var yon = Input.get_vector("ui_left" ,"ui_right","ui_up","ui_down")
	
	if yon != Vector2.ZERO:
		son_yon = yon
		
	dash_bekleme = maxf(0.0, dash_bekleme - delta)
	
	
	# Q ile Dash atma 
	if Input.is_key_pressed(KEY_Q) and dash_kalan <= 0.0 and dash_bekleme <= 0.0:
		dash_kalan = 0.16
		dash_bekleme = dash_bekleme_suresi
	if dash_kalan > 0.0:
		dash_kalan = maxf(0.0, dash_kalan - delta)
		velocity = son_yon * dash_hizi
		
	else:
		var carpan = 1.0
		
		if Input.is_key_pressed(KEY_SHIFT):
			carpan = kosma_carpani
			
		velocity = yon * hız * carpan
	move_and_slide()
	
	#yürüme animasyonu
	if velocity.length() > 0:
		anim_zamani += delta
		if anim_zamani >= 0.15:
			anim_zamani = 0.0
			anim_kare = 1 - anim_kare
			queue_redraw()
	else:
		if anim_kare != 0:
			anim_kare = 0
			queue_redraw()
	
func _draw():
	#vücut
	draw_rect(
		Rect2(Vector2(-12, -16), Vector2(24, 32)),
		Color("458470ff")
	)
	#kafa
	draw_circle(Vector2(0, -21), 10, Color("3e8093ff"))
	#göz
	draw_circle(Vector2(-4, -23), 2, Color("000000ff"))
	draw_circle(Vector2(4, -23), 2, Color("000000ff"))
	
	#kollar 
	var kol_salincagi = 4.0 if anim_kare == 0 else -4.0
	
	draw_line(
		Vector2(-10, -8),
		Vector2(-14, 2 + kol_salincagi),
		Color("458470ff"),
		5.0
	)
	
	draw_line(
		Vector2(10, -8),
		Vector2(14, 2 - kol_salincagi),
		Color("458470ff"),
		5.0
		)
		
	# bacaklar
	draw_line(
		Vector2(-5, 12),
		Vector2(-6 - kol_salincagi, 20),
		Color("303840ff"),
		5.0
	)
	
	draw_line(
		Vector2(5, 12),
		Vector2(6 + kol_salincagi, 20),
		Color("303840ff"),
		5.0
	)
		
