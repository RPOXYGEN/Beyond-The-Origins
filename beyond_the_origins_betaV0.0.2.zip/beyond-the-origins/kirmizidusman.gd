extends CharacterBody2D

@export var yurume_hizi = 90.0
var oyuncu: CharacterBody2D

func _ready() -> void:
	oyuncu = get_tree().current_scene.find_child("Player", true, false) as CharacterBody2D


func _physics_process(delta: float) -> void:
	if not is_instance_valid(oyuncu):
		velocity = Vector2.ZERO
		move_and_slide()
		return
	
	velocity =global_position.direction_to(oyuncu.global_position) * yurume_hizi
	move_and_slide()
	
	
func _draw() -> void:
	draw_rect(Rect2(Vector2(-12,-16), Vector2(24,32)), Color("d73535ff"))
	draw_circle(Vector2(0,-21), 10, Color("e74d4dff"))
	draw_circle(Vector2(-4, -23), 2, Color.BLACK)
	draw_circle(Vector2(4, -23), 2, Color.BLACK)
	
	var kol_salincagi = 4.0 if Engine.get_physics_frames() % 20 < 10 else -4.0
	
	draw_line(Vector2(-10,-8), Vector2(-14,2 + kol_salincagi), Color("d93636ff"), 5.0)
	draw_line(Vector2(10,-8), Vector2(14,2 - kol_salincagi), Color("d93636ff"), 5.0)
	draw_line(Vector2(-5,12), Vector2(-6 - kol_salincagi,20), Color("303840ff"), 5.0)
	draw_line(Vector2(5,12), Vector2(6 + kol_salincagi,20), Color("303840ff"), 5.0)
	
	queue_redraw()
